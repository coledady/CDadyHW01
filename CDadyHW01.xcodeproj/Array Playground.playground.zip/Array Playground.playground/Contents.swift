//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)
str = "Hello Developer"
print(str)
let message1 = "You Are Awesome!"
var message2 = "You Are Great!"
let message3 = "You Are Fantastic!"
str = message2
print(str)
message2 = message3
print(message2)

var messages = ["You are awesome!", "You are great!", "You are fantastic!", "When the genius bar needs help, they call you.", "You brighten my day!"]
print(messages)
print(messages[0])
print(messages[3])
messages[messages.count - 1]
messages = messages + ["Hey, Fabulous!"]
messages.count
messages += ["Hey, Wonderful!"]
messages.insert("You Are Sweeter than Maple Syrup", at: 2)
messages.remove(at: 2)
print(messages)








